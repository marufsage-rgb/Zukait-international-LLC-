# Zukait International LLC – Auto Services Website

Complete multi-page website for **Zukait Auto Services** (Hi-Tech Automotive Workshop) in Barka, Sultanate of Oman.

## Company Info
- **Name:** Zukait International LLC
- **Type:** Hi-Tech Automotive Workshop
- **Location:** P.O. Box 1921, Barka, Postal Code 130, Oman
- **Phone:** +968 9321 1154 / +968 9240 3420
- **C.R. No.:** 1194220

## Features
- Responsive design (mobile + desktop)
- Orange + dark branding matching workshop colors
- Pages: Home, About, Services, Contact
- Contact / booking form that saves to MySQL
- Ready for shared hosting or VPS

## How to Upload to Hosting

1. **Create MySQL database** on your hosting panel (cPanel / Plesk / etc.)
2. Import `sql/schema.sql` into the new database
3. Edit `includes/config.php`:
   - Set DB_HOST, DB_NAME, DB_USER, DB_PASS to your hosting database details
4. Upload **all files** (via FTP or File Manager) to your domain’s `public_html` folder
5. Visit your domain – the site is ready!

## Local Testing
```bash
# With XAMPP / WAMP: put folder in htdocs
# Or use PHP built-in server:
php -S localhost:8000
```

## Folder Structure
```
zukait-international/
├── css/style.css
├── includes/
│   ├── config.php
│   ├── header.php
│   └── footer.php
├── sql/schema.sql
├── index.php
├── about.php
├── services.php
├── contact.php
└── README.md
```

## Notes for Production
- Change default admin password
- Set `display_errors` to 0 in config.php
- Add your real email if available
- Consider adding WhatsApp click-to-chat button

Equipped to serve you better.
