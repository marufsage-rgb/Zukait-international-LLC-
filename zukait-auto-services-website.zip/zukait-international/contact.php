<?php
$page_title = 'Contact';
require_once 'includes/config.php';

$success = false;
$error = '';
$form_data = [
    'full_name' => '',
    'email' => '',
    'phone' => '',
    'car_model' => '',
    'service_interest' => '',
    'message' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $form_data['full_name'] = trim($_POST['full_name'] ?? '');
    $form_data['email'] = trim($_POST['email'] ?? '');
    $form_data['phone'] = trim($_POST['phone'] ?? '');
    $form_data['car_model'] = trim($_POST['car_model'] ?? '');
    $form_data['service_interest'] = trim($_POST['service_interest'] ?? '');
    $form_data['message'] = trim($_POST['message'] ?? '');

    if (empty($form_data['full_name']) || empty($form_data['phone']) || empty($form_data['message'])) {
        $error = 'Please fill in all required fields (Name, Phone, and Message).';
    } elseif (!empty($form_data['email']) && !filter_var($form_data['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        try {
            $pdo = getDB();
            $stmt = $pdo->prepare("
                INSERT INTO inquiries (full_name, email, phone, company, service_interest, message)
                VALUES (:full_name, :email, :phone, :car_model, :service_interest, :message)
            ");
            $stmt->execute([
                ':full_name' => $form_data['full_name'],
                ':email' => $form_data['email'] ?: null,
                ':phone' => $form_data['phone'],
                ':car_model' => $form_data['car_model'] ?: null,
                ':service_interest' => $form_data['service_interest'] ?: null,
                ':message' => $form_data['message']
            ]);
            $success = true;
            $form_data = array_fill_keys(array_keys($form_data), '');
        } catch (PDOException $e) {
            $error = 'Sorry, we could not save your message. Please call us directly.';
        }
    }
}

require_once 'includes/header.php';
?>

<section class="section">
    <div class="container">
        <div class="contact-grid">
            <div class="contact-info">
                <h2>Contact the Workshop</h2>
                <p>Visit us in Barka or call for an appointment. We are ready to serve you.</p>

                <div class="info-item">
                    <i class="fas fa-phone"></i>
                    <div>
                        <strong>Phone / WhatsApp</strong>
                        <span><?php echo SITE_PHONE; ?></span><br>
                        <span><?php echo SITE_PHONE2; ?></span>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-map-marker-alt"></i>
                    <div>
                        <strong>Address</strong>
                        <span><?php echo SITE_ADDRESS; ?></span>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-file-alt"></i>
                    <div>
                        <strong>Commercial Registration</strong>
                        <span><?php echo SITE_CR; ?></span>
                    </div>
                </div>
                <div class="info-item">
                    <i class="fas fa-clock"></i>
                    <div>
                        <strong>Working Hours</strong>
                        <span>Saturday – Thursday (Call for exact times)</span>
                    </div>
                </div>
            </div>

            <div class="contact-form">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <strong>Thank you!</strong> Your request has been received. We will contact you soon.
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-error">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="contact.php" novalidate>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="full_name">Full Name *</label>
                            <input type="text" id="full_name" name="full_name" required
                                   value="<?php echo htmlspecialchars($form_data['full_name']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone / WhatsApp *</label>
                            <input type="tel" id="phone" name="phone" required
                                   value="<?php echo htmlspecialchars($form_data['phone']); ?>"
                                   placeholder="+968 ...">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email"
                                   value="<?php echo htmlspecialchars($form_data['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="car_model">Car Model / Year</label>
                            <input type="text" id="car_model" name="car_model"
                                   value="<?php echo htmlspecialchars($form_data['car_model']); ?>"
                                   placeholder="e.g. Toyota Camry 2018">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="service_interest">Service Needed</label>
                        <select id="service_interest" name="service_interest">
                            <option value="">— Select Service —</option>
                            <?php
                            $services = [
                                'Oil & Quick Lube',
                                'Brake & Axle',
                                'Engine & Gear Repair',
                                'Electrical Works',
                                'AC Works',
                                'Computer Checking',
                                'Denting & Painting',
                                'General Mechanical',
                                'Other / Inspection'
                            ];
                            foreach ($services as $s) {
                                $selected = ($form_data['service_interest'] === $s) ? 'selected' : '';
                                echo "<option value=\"" . htmlspecialchars($s) . "\" $selected>" . htmlspecialchars($s) . "</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="message">Message / Problem Description *</label>
                        <textarea id="message" name="message" required
                                  placeholder="Describe the problem or service you need..."><?php echo htmlspecialchars($form_data['message']); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-dark"><i class="fas fa-paper-plane"></i> Send Request</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
