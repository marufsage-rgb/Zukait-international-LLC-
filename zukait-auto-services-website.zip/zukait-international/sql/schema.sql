-- Zukait International LLC - Hi-Tech Automotive Workshop
-- Database Schema for Barka, Oman workshop website

CREATE DATABASE IF NOT EXISTS zukait_international
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE zukait_international;

-- Contact / Service request form submissions
CREATE TABLE IF NOT EXISTS inquiries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(150) NOT NULL,
    email VARCHAR(180) DEFAULT NULL,
    phone VARCHAR(50) NOT NULL,
    company VARCHAR(150) DEFAULT NULL COMMENT 'Used for Car Model / Year',
    service_interest VARCHAR(100) DEFAULT NULL,
    message TEXT NOT NULL,
    status ENUM('new', 'in_progress', 'closed') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Optional admin table
CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(150) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default admin (password: admin123 – change after first login!)
INSERT INTO admins (username, password_hash, full_name) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Workshop Admin');
