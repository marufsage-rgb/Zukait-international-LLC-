<?php
$page_title = 'Services';
require_once 'includes/header.php';
?>

<section class="section">
    <div class="container">
        <div class="section-header">
            <h2>Our Services</h2>
            <p>Complete automotive care – from quick lube to major mechanical and electrical repairs.</p>
        </div>

        <div class="service-list">
            <div class="service-item">
                <div class="icon"><i class="fas fa-oil-can"></i></div>
                <div>
                    <h3>Oil & Quick Lube</h3>
                    <p>Engine oil change, filter replacement, and full lubrication service. Fast and professional using quality oils suitable for your vehicle.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-car"></i></div>
                <div>
                    <h3>Brake & Axle</h3>
                    <p>Brake pad and disc replacement, brake fluid service, axle repair, and suspension work to ensure your safety on the road.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-cogs"></i></div>
                <div>
                    <h3>Engine & Gear Repair</h3>
                    <p>Engine diagnostics, overhaul, timing belt, water pump, and complete gearbox / transmission repair by skilled technicians.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-bolt"></i></div>
                <div>
                    <h3>Electrical Works</h3>
                    <p>Battery testing and replacement, wiring repairs, lights, starters, alternators, and all electrical system troubleshooting.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-snowflake"></i></div>
                <div>
                    <h3>AC Works</h3>
                    <p>Air conditioning diagnosis, gas recharging, compressor repair, and full cooling system service for comfortable driving.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-laptop"></i></div>
                <div>
                    <h3>Computer Checking / Diagnosis</h3>
                    <p>Advanced computer diagnostics for engine management, ABS, airbags, and electronic systems on modern vehicles.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-paint-roller"></i></div>
                <div>
                    <h3>Denting & Painting</h3>
                    <p>Bodywork, dent removal, and professional painting services to restore your vehicle’s appearance.</p>
                </div>
            </div>

            <div class="service-item">
                <div class="icon"><i class="fas fa-wrench"></i></div>
                <div>
                    <h3>General Mechanical</h3>
                    <p>Full mechanical inspection, preventive maintenance, and repairs for all makes and models.</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="cta-banner">
    <div class="container">
        <h2>Book your service today</h2>
        <p>Call us or send a message – we will take care of your car.</p>
        <a href="contact.php" class="btn btn-primary"><i class="fas fa-phone"></i> Contact Workshop</a>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
