<?php
/**
 * Zukait International LLC - Database Configuration
 * Hi-Tech Automotive Workshop - Barka, Oman
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'zukait_international');
define('DB_USER', 'root');          // Change to your MySQL username
define('DB_PASS', '');              // Change to your MySQL password
define('DB_CHARSET', 'utf8mb4');

// Site settings - Real company info from workshop
define('SITE_NAME', 'Zukait International LLC');
define('SITE_TAGLINE', 'Hi-Tech Automotive Workshop');
define('SITE_EMAIL', 'info@zukaitauto.com');
define('SITE_PHONE', '+968 9321 1154');
define('SITE_PHONE2', '+968 9240 3420');
define('SITE_ADDRESS', 'P.O. Box 1921, Barka, Postal Code 130, Sultanate of Oman');
define('SITE_CR', 'C.R. No. 1194220');

// Error reporting (set to 0 in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

/**
 * Create PDO connection
 */
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("Database connection failed. Please check your configuration.");
        }
    }
    return $pdo;
}
