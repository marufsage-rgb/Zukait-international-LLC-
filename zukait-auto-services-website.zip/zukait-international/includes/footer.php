</main>
    <footer class="site-footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-col">
                    <h3>Zukait International LLC</h3>
                    <p>Hi-Tech Automotive Workshop in Barka, Oman. Professional car service, repair and maintenance with modern equipment and experienced technicians.</p>
                    <p style="margin-top:10px;font-size:0.9rem;opacity:0.8;"><?php echo SITE_CR; ?></p>
                </div>
                <div class="footer-col">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="index.php">Home</a></li>
                        <li><a href="about.php">About Us</a></li>
                        <li><a href="services.php">Services</a></li>
                        <li><a href="contact.php">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-col">
                    <h4>Contact</h4>
                    <ul class="contact-list">
                        <li><i class="fas fa-phone"></i> <?php echo SITE_PHONE; ?></li>
                        <li><i class="fas fa-phone"></i> <?php echo SITE_PHONE2; ?></li>
                        <li><i class="fas fa-map-marker-alt"></i> <?php echo SITE_ADDRESS; ?></li>
                    </ul>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> Zukait International LLC. All rights reserved. | Equipped to serve you better</p>
            </div>
        </div>
    </footer>
    <script>
        const navToggle = document.getElementById('navToggle');
        const mainNav = document.getElementById('mainNav');
        if (navToggle && mainNav) {
            navToggle.addEventListener('click', () => {
                mainNav.classList.toggle('open');
            });
        }
    </script>
</body>
</html>
