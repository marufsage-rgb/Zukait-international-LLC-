<?php
if (!defined('SITE_NAME')) {
    require_once __DIR__ . '/config.php';
}
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Zukait International LLC - Hi-Tech Automotive Workshop in Barka, Oman. Oil change, brakes, engine repair, electrical, AC, computer diagnosis and more.">
    <title><?php echo isset($page_title) ? htmlspecialchars($page_title) . ' | ' : ''; ?><?php echo SITE_NAME; ?> - Auto Services</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a href="index.php" class="logo">
                <span class="logo-icon">Z</span>
                <span class="logo-text">Zukait <span>Auto Services</span></span>
            </a>
            <nav class="main-nav" id="mainNav">
                <a href="index.php" class="<?php echo $current_page === 'index' ? 'active' : ''; ?>">Home</a>
                <a href="about.php" class="<?php echo $current_page === 'about' ? 'active' : ''; ?>">About</a>
                <a href="services.php" class="<?php echo $current_page === 'services' ? 'active' : ''; ?>">Services</a>
                <a href="contact.php" class="<?php echo $current_page === 'contact' ? 'active' : ''; ?>">Contact</a>
            </nav>
            <button class="nav-toggle" id="navToggle" aria-label="Toggle menu">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>
    <main>
