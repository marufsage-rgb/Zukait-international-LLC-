<?php
$page_title = 'About Us';
require_once 'includes/header.php';
?>

<section class="section">
    <div class="container">
        <div class="about-grid">
            <div class="about-content">
                <h2>About Zukait International LLC</h2>
                <p><strong>Zukait Auto Services</strong> is a Hi-Tech Automotive Workshop located in Barka, Sultanate of Oman. We provide professional car repair and maintenance services for all vehicle types.</p>
                <p>Our workshop is fully equipped with modern tools, diagnostic computers, and hydraulic lifts. We handle everything from routine oil changes to major engine and gearbox repairs.</p>
                <p>We are committed to honest work, fair pricing, and customer satisfaction. Our motto: <em>“Equipped to serve you better.”</em></p>
                <div class="stats">
                    <div class="stat-item">
                        <strong>6+</strong>
                        <span>Core Services</span>
                    </div>
                    <div class="stat-item">
                        <strong>Barka</strong>
                        <span>Location</span>
                    </div>
                    <div class="stat-item">
                        <strong>Hi-Tech</strong>
                        <span>Workshop</span>
                    </div>
                </div>
            </div>
            <div class="about-image">
                <i class="fas fa-car-side"></i>
            </div>
        </div>
    </div>
</section>

<section class="section section-alt">
    <div class="container">
        <div class="section-header">
            <h2>Company Information</h2>
            <p>Registered company details</p>
        </div>
        <div class="cards">
            <div class="card">
                <div class="card-icon"><i class="fas fa-building"></i></div>
                <h3>Legal Name</h3>
                <p>Zukait International LLC<br>Hi-Tech Automotive Workshop</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-map-marker-alt"></i></div>
                <h3>Address</h3>
                <p>P.O. Box 1921<br>Barka, Postal Code 130<br>Sultanate of Oman</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-file-alt"></i></div>
                <h3>Commercial Registration</h3>
                <p>C.R. No. 1194220</p>
            </div>
        </div>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
