<?php
$page_title = 'Home';
require_once 'includes/header.php';
?>

<section class="hero">
    <div class="container">
        <div class="hero-content">
            <h1>Professional <span>Auto Services</span> in Barka</h1>
            <p>Zukait International LLC – Hi-Tech Automotive Workshop. Oil change, brakes, engine & gear repair, electrical works, AC service, computer diagnosis and more. Equipped to serve you better.</p>
            <div class="hero-buttons">
                <a href="services.php" class="btn btn-primary"><i class="fas fa-wrench"></i> Our Services</a>
                <a href="contact.php" class="btn btn-outline"><i class="fas fa-phone"></i> Book Appointment</a>
            </div>
        </div>
    </div>
</section>

<section class="section">
    <div class="container">
        <div class="section-header">
            <h2>Our Main Services</h2>
            <p>Complete car care under one roof with modern equipment and skilled technicians.</p>
        </div>
        <div class="cards">
            <div class="card">
                <div class="card-icon"><i class="fas fa-oil-can"></i></div>
                <h3>Oil & Quick Lube</h3>
                <p>Fast oil change and lubrication service to keep your engine running smoothly.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-car"></i></div>
                <h3>Brake & Axle</h3>
                <p>Brake pads, discs, axles and suspension repairs for safe driving.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-cogs"></i></div>
                <h3>Engine & Gear Repair</h3>
                <p>Complete engine overhaul and gearbox repair by experienced mechanics.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-bolt"></i></div>
                <h3>Electrical Works</h3>
                <p>Battery, wiring, lights, sensors and full electrical system diagnosis.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-snowflake"></i></div>
                <h3>AC Works</h3>
                <p>Air conditioning repair, gas refill and cooling system service.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-laptop"></i></div>
                <h3>Computer Checking</h3>
                <p>Computer diagnosis and electronic system scanning for modern vehicles.</p>
            </div>
        </div>
    </div>
</section>

<section class="section section-alt">
    <div class="container">
        <div class="section-header">
            <h2>Why Choose Zukait Auto Services?</h2>
            <p>Trusted workshop in Barka with quality workmanship and honest service.</p>
        </div>
        <div class="cards">
            <div class="card">
                <div class="card-icon"><i class="fas fa-tools"></i></div>
                <h3>Modern Equipment</h3>
                <p>Hi-tech tools and diagnostic machines for accurate and efficient repairs.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-user-tie"></i></div>
                <h3>Skilled Technicians</h3>
                <p>Experienced team ready to handle all major car brands and models.</p>
            </div>
            <div class="card">
                <div class="card-icon"><i class="fas fa-clock"></i></div>
                <h3>Quick Service</h3>
                <p>We value your time – fast turnaround without compromising quality.</p>
            </div>
        </div>
    </div>
</section>

<section class="cta-banner">
    <div class="container">
        <h2>Need car service today?</h2>
        <p>Call us or visit our workshop in Barka. We are ready to help.</p>
        <a href="contact.php" class="btn btn-primary"><i class="fas fa-phone-alt"></i> Contact Us Now</a>
    </div>
</section>

<?php require_once 'includes/footer.php'; ?>
